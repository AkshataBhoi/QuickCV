
  # SaaS Landing Page Design

  This is a code bundle for SaaS Landing Page Design. The original project is available at https://www.figma.com/design/dzSkJsAwh5JgeTMMVaFta4/SaaS-Landing-Page-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  